Thank you in advance for your consideration. 
As always, a fan of the work and curation of Taper. 

- leia 